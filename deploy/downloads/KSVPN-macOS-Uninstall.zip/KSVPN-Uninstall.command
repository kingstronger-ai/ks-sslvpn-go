#!/bin/bash
# KSVPN macOS 客户端卸载工具
# 用法：双击本文件（.command）在「终端」中运行，按提示输入 Mac 登录密码。
# 请先退出客户端并断开 VPN 连接再运行。
set -u

USER_HOME="$HOME"
for arg in "$@"; do
  case "$arg" in --user-home=*) USER_HOME="${arg#*=}" ;; esac
done

# 系统级文件（/Applications、/Library/LaunchDaemons、helper、Engine）需要 root。
# 用参数把原用户 HOME 带过来，避免 sudo 后 $HOME 变成 /var/root 而漏删/误删。
if [ "$(id -u)" -ne 0 ]; then
  echo "KSVPN 卸载需要管理员权限，请输入 Mac 登录密码："
  exec /usr/bin/sudo /bin/bash "$0" "--user-home=$USER_HOME"
fi

echo "=========================================="
echo " KSVPN 客户端卸载"
echo "=========================================="
echo "用户目录：$USER_HOME"
echo

# 1) 结束客户端与其拉起的 OpenVPN 进程
/usr/bin/osascript -e 'tell application "KSVPN" to quit' >/dev/null 2>&1 || :
for name in KSVPN "KSVPN Full"; do /usr/bin/pkill -x "$name" >/dev/null 2>&1 || :; done
for pid in $(/usr/bin/pgrep -f openvpn 2>/dev/null || :); do
  cmd=$(/bin/ps -p "$pid" -o command= 2>/dev/null || :)
  case "$cmd" in
    *KSVPN*|*vpn*|*VPN*) /bin/kill -TERM "$pid" 2>/dev/null || : ;;
  esac
done
echo "[1/5] 已结束客户端 / VPN 进程"

# 2) 按安装收据精确删除 .pkg 装进系统的文件。
#    不写死任何历史产品名：包标识符按 tech.*vpn 特征匹配，路径由 pkgutil 反查。
PKG_IDS=$(/usr/sbin/pkgutil --pkgs 2>/dev/null | /usr/bin/grep -Ei '^tech\..*vpn' || :)
if [ -z "$PKG_IDS" ]; then
  echo "[2/5] 未找到 KSVPN 安装收据（可能已卸载，或是手工拖入的 .app）"
else
  for id in $PKG_IDS; do
    echo "  卸载安装收据：$id"
    # 停掉并删除本包的 LaunchDaemon / 特权 helper（路径同样从收据反查）
    /usr/sbin/pkgutil --only-files --files "$id" 2>/dev/null | while IFS= read -r rel; do
      [ -n "$rel" ] || continue
      target="/$rel"
      case "$target" in
        /Library/LaunchDaemons/*.plist)
          label=$(/usr/bin/basename "$target" .plist)
          /bin/launchctl bootout system/"$label" >/dev/null 2>&1 || :
          ;;
      esac
      /bin/rm -f "$target" 2>/dev/null || :
    done
    # 目录按深度倒序 rmdir，只删空目录，不会碰其它软件
    /usr/sbin/pkgutil --only-dirs --files "$id" 2>/dev/null |
      /usr/bin/awk -F/ '{print NF, $0}' | /usr/bin/sort -rn |
      /usr/bin/sed 's/^[0-9][0-9]* //' |
      while IFS= read -r rel; do
        [ -n "$rel" ] || continue
        /bin/rmdir "/$rel" 2>/dev/null || :
      done
    /usr/sbin/pkgutil --forget "$id" >/dev/null 2>&1 || :
  done
  echo "[2/5] 已按安装收据删除系统级文件与后台服务"
fi

# 3) 兜底清理：源码包 .app 方式安装、以及收据丢失时的遗留系统文件
for app in "/Applications/KSVPN.app" "/Applications/KSVPN Full.app"; do
  [ -e "$app" ] && /bin/rm -rf "$app" && echo "  删除 $app"
done
for plist in /Library/LaunchDaemons/*vpn*service*.plist /Library/LaunchDaemons/*VPN*service*.plist; do
  [ -f "$plist" ] || continue
  label=$(/usr/bin/basename "$plist" .plist)
  /bin/launchctl bootout system/"$label" >/dev/null 2>&1 || :
  /bin/rm -f "$plist" && echo "  删除 $plist"
done
for helper in /Library/PrivilegedHelperTools/*vpn* /Library/PrivilegedHelperTools/*VPN*; do
  [ -e "$helper" ] && /bin/rm -f "$helper" && echo "  删除 $helper"
done
echo "[3/5] 已清理 .app / LaunchDaemon / 特权 helper"

# 4) 清理用户数据：配置、证书、profile、日志、网关覆盖文件。
#    旧版本目录按文件特征识别（含 gateway.txt / profiles / client.json），不写死产品名。
for d in "$USER_HOME/Library/Application Support/KSVPN" \
         "$USER_HOME/Library/Application Support"/*VPN \
         "$USER_HOME/Library/Application Support"/*vpn*; do
  [ -d "$d" ] || continue
  if [ -e "$d/gateway.txt" ] || [ -d "$d/profiles" ] || [ -e "$d/client.json" ] || [ -e "$d/openvpn.log" ]; then
    /bin/rm -rf "$d" && echo "  删除 $d"
  fi
done
for pattern in "$USER_HOME/Library/Preferences/"*vpn* "$USER_HOME/Library/Preferences/"*VPN* \
               "$USER_HOME/Library/Logs/"*VPN* "$USER_HOME/Library/Logs/"*vpn* \
               "$USER_HOME/Library/Caches/"*vpn*; do
  [ -e "$pattern" ] && /bin/rm -rf "$pattern"
done
# 桌面/下载里可能残留的本工具自身不删除
echo "[4/5] 已清理用户配置、证书与日志"

# 5) 完成
echo "[5/5] 卸载完成"
echo
echo "说明：OpenVPN 引擎由本产品自带，已随上述路径一并删除；"
echo "      如曾单独用 Homebrew 安装过 openvpn，请另执行 brew uninstall openvpn。"
echo "      若「系统设置 → 通用 → 登录项与扩展」里还有残留后台项目，请手动移除。"
echo
echo "按回车键关闭窗口…"
read -r _ || :
