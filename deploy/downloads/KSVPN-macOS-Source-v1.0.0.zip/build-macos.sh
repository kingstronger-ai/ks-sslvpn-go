#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
APP="$BUILD/KSVPN.app"
CONTENTS="$APP/Contents"

rm -rf "$BUILD"
mkdir -p "$CONTENTS/MacOS" "$CONTENTS/Resources"

iconutil -c icns "$ROOT/Resources/KSVPN.iconset" -o "$CONTENTS/Resources/KSVPN.icns"
cp "$ROOT/Resources/ksvpn-icon.png" "$CONTENTS/Resources/KSIcon.png"

swiftc -parse-as-library \
  "$ROOT/Sources/KSVPN/App.swift" \
  -o "$CONTENTS/MacOS/KSVPN" \
  -framework SwiftUI -framework AppKit -framework Security \
  -target "$(uname -m)-apple-macosx13.0"

cat > "$CONTENTS/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleExecutable</key><string>KSVPN</string>
  <key>CFBundleIdentifier</key><string>tech.ksvpn.client</string>
  <key>CFBundleName</key><string>KSVPN</string>
  <key>CFBundleDisplayName</key><string>KSVPN</string>
  <key>CFBundleIconFile</key><string>KSVPN</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>0.3.4</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST

# Makes an internal, locally runnable build. Replace with Developer ID signing for distribution.
codesign --force --deep --sign - "$APP"
echo "$APP"
