# KSVPN for macOS

This is the macOS 13+ native companion for the Windows client. It uses the same Feishu SSO, LDAP login, personal-profile download, and OpenVPN connection flow.

## 老用户升级版（使用 Mac 已有 OpenVPN）

1. Install Xcode Command Line Tools and OpenVPN:
   `xcode-select --install`
   `brew install openvpn`
2. Run `bash build-macos.sh`.
3. Move `build/KSVPN.app` to `/Applications`.

## 新用户完整版（OpenVPN 内置到 App）

OpenVPN only needs to be installed on the build Mac; the resulting app does not require it on user Macs.

1. Install Xcode Command Line Tools and the build dependency: `brew install openvpn`.
2. Run `bash build-macos-full.sh`.
3. Move `build/KSVPN Full.app` to `/Applications`.

Both scripts create ad-hoc signed internal apps. For company-wide distribution, sign with an Apple Developer ID certificate and notarize the app before packaging it as a `.dmg` or `.pkg`.
