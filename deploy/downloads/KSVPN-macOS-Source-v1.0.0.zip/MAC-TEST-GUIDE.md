# KSVPN macOS 内部测试

## 新电脑：构建内置 OpenVPN 的完整版

1. 解压源码包并打开“终端”。
2. 安装 Apple 命令行开发工具：

   `xcode-select --install`

3. 安装 Homebrew（若已有可跳过），然后执行：

   `brew install openvpn`

4. 进入解压目录并构建：

   `cd ~/Downloads/KSVPN-macOS-Source-v1.0.0`

   `bash build-macos-full.sh`

5. 构建结果：

   `build/KSVPN Full.app`

6. 将 App 拖入“应用程序”文件夹。首次启动请在 Finder 中右键 App，选择“打开”。

OpenVPN 只用于构建；生成的 Full.app 已携带 OpenVPN 和动态库，测试用户不必另装。

## 已安装 OpenVPN 的老用户版本

执行：`bash build-macos.sh`

构建结果：`build/KSVPN.app`

## 注意

- 脚本会按当前 Mac 架构构建：Apple Silicon 构建 arm64，Intel Mac 构建 x86_64。
- 当前为临时签名的内部测试版本；面向全员分发前需要 Apple Developer ID 签名和公证。
- 首次建立 VPN 时 macOS 会要求输入管理员密码，这是 OpenVPN 创建网络接口和路由所必需的。
