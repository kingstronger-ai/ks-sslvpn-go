import Foundation
import SwiftUI
import AppKit
import Security

// 默认认证网关（当前 sslvpn-go 管理端口 58443，不要带 /feishu-sso 后缀）。
// 换服务器时无需重新编译：在 ~/Library/Application Support/KSVPN/gateway.txt
// 写一行地址即可覆盖，例如 https://vpn.example.com:58443
private let defaultGateway = "https://vpn.example.com:58443"
private let gateway: String = {
    let dir = NSHomeDirectory() + "/Library/Application Support/KSVPN"
    let path = dir + "/gateway.txt"
    if let raw = try? String(contentsOfFile: path, encoding: .utf8) {
        let v = raw.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if v.hasPrefix("https://") || v.hasPrefix("http://") { return v }
    }
    return defaultGateway
}()

private struct DeviceStart: Decodable {
    let device_code: String
    let device_verifier: String
    let auth_url: String
    let expires_in: Int
    let interval: Int
}

private struct DevicePoll: Decodable {
    let status: String
    let username: String?
    let vpn_token: String?
    let error: String?
}

private enum VPNError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let text) = self { return text }
        return "未知错误"
    }
}

private func shellQuote(_ value: String) -> String {
    return "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
}

private func appleScriptQuote(_ value: String) -> String {
    return "\"" + value.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
}

private func run(_ executable: String, _ arguments: [String]) throws -> String {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: executable)
    process.arguments = arguments
    let pipe = Pipe()
    process.standardOutput = pipe
    process.standardError = pipe
    try process.run()
    process.waitUntilExit()
    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    let output = String(data: data, encoding: .utf8) ?? ""
    if process.terminationStatus != 0 { throw VPNError.message(output.isEmpty ? "命令执行失败" : output) }
    return output.trimmingCharacters(in: .whitespacesAndNewlines)
}

@MainActor
final class VPNViewModel: ObservableObject {
    // 关闭窗口时需要从 AppDelegate 断开连接，故全局共享一份实例
    static let shared = VPNViewModel()

    @Published var username = UserDefaults.standard.string(forKey: "vpnUsername") ?? ""
    @Published var password = ""
    @Published var rememberPassword = false
    @Published var status = "准备就绪"
    @Published var statusKind = 0
    @Published var isBusy = false
    @Published var isConnected = false

    private var vpnPID: Int32?
    private let fm = FileManager.default
    private let service = "tech.ksvpn.client"

    init() {
        if let saved = keychainRead(account: "ldap-password") {
            password = saved
            rememberPassword = true
        }
    }

    private var appDir: URL {
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("KSVPN", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private func setStatus(_ text: String, kind: Int = 0) {
        status = text
        statusKind = kind
    }

    private func request(path: String, body: [String: String]) async throws -> (Data, HTTPURLResponse) {
        guard let url = URL(string: gateway + path) else { throw VPNError.message("认证网关地址无效") }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw VPNError.message("认证网关响应无效") }
        return (data, http)
    }

    private func json<T: Decodable>(_ type: T.Type, path: String, body: [String: String]) async throws -> T {
        let (data, response) = try await request(path: path, body: body)
        if !(200...299).contains(response.statusCode) {
            let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
            throw VPNError.message(object?["error"] as? String ?? "认证网关拒绝请求")
        }
        return try JSONDecoder().decode(type, from: data)
    }

    private func installProfile(data: Data, username: String) throws -> URL {
        guard username.range(of: #"^[A-Za-z0-9_.@-]{1,64}$"#, options: .regularExpression) != nil else {
            throw VPNError.message("服务端返回的 VPN 账号格式不正确")
        }
        let archive = appDir.appendingPathComponent("profile-\(UUID().uuidString).tgz")
        let extract = appDir.appendingPathComponent("extract-\(UUID().uuidString)", isDirectory: true)
        defer { try? fm.removeItem(at: archive); try? fm.removeItem(at: extract) }
        try data.write(to: archive, options: .atomic)
        try fm.createDirectory(at: extract, withIntermediateDirectories: true)
        let listing = try run("/usr/bin/tar", ["-tzf", archive.path])
        let entries = listing.split(separator: "\n").map(String.init)
        guard !entries.isEmpty else { throw VPNError.message("个人 VPN 配置包为空") }
        for entry in entries {
            if entry.hasPrefix("/") || entry.split(separator: "/").contains("..") {
                throw VPNError.message("个人 VPN 配置包包含不安全路径")
            }
        }
        _ = try run("/usr/bin/tar", ["-xzf", archive.path, "-C", extract.path])
        let enumerator = fm.enumerator(at: extract, includingPropertiesForKeys: [.isRegularFileKey])
        let profiles = (enumerator?.allObjects as? [URL] ?? []).filter { $0.pathExtension.lowercased() == "ovpn" }
        guard profiles.count == 1 else { throw VPNError.message("个人 VPN 配置包中没有唯一的 .ovpn 文件") }
        let profileDir = appDir.appendingPathComponent("profiles", isDirectory: true)
        try fm.createDirectory(at: profileDir, withIntermediateDirectories: true)
        let destination = profileDir.appendingPathComponent("\(username).ovpn")
        try? fm.removeItem(at: destination)
        try fm.copyItem(at: profiles[0], to: destination)
        try fm.setAttributes([.posixPermissions: 0o600], ofItemAtPath: destination.path)
        return destination
    }

    private func openVPNPath() throws -> String {
        let bundled = Bundle.main.url(forAuxiliaryExecutable: "openvpn")?.path
        let candidates = [bundled, "/opt/homebrew/sbin/openvpn", "/usr/local/sbin/openvpn", "/opt/local/sbin/openvpn"].compactMap { $0 }
        if let path = candidates.first(where: { fm.isExecutableFile(atPath: $0) }) { return path }
        throw VPNError.message("未找到 OpenVPN。请先运行：brew install openvpn")
    }

    private func connect(username: String, secret: String, profile: URL) async throws -> String {
        let openvpn = try openVPNPath()
        let auth = appDir.appendingPathComponent("auth-\(UUID().uuidString).txt")
        let log = appDir.appendingPathComponent("openvpn.log")
        try "\(username)\n\(secret)\n".write(to: auth, atomically: true, encoding: .utf8)
        try fm.setAttributes([.posixPermissions: 0o600], ofItemAtPath: auth.path)
        try? fm.removeItem(at: log)
        defer { try? fm.removeItem(at: auth) }

        let command = "nohup \(shellQuote(openvpn)) --config \(shellQuote(profile.path)) --auth-user-pass \(shellQuote(auth.path)) --auth-nocache --verb 3 --log \(shellQuote(log.path)) >/dev/null 2>&1 & echo $!"
        let appleScript = "do shell script \(appleScriptQuote(command)) with administrator privileges"
        let pidText = try run("/usr/bin/osascript", ["-e", appleScript])
        guard let pid = Int32(pidText.trimmingCharacters(in: .whitespacesAndNewlines)) else {
            throw VPNError.message("无法启动 OpenVPN")
        }
        vpnPID = pid

        for _ in 0..<45 {
            try await Task.sleep(nanoseconds: 1_000_000_000)
            let text = (try? String(contentsOf: log, encoding: .utf8)) ?? ""
            if text.contains("AUTH_FAILED") { try? stopProcess(); throw VPNError.message("VPN 账号或密码错误，服务器拒绝登录") }
            if text.contains("Initialization Sequence Completed") {
                if let match = text.range(of: #"ifconfig\s+(\d{1,3}(?:\.\d{1,3}){3})"#, options: .regularExpression) {
                    let fragment = String(text[match])
                    return fragment.split(separator: " ").last.map(String.init) ?? ""
                }
                return ""
            }
        }
        try? stopProcess()
        throw VPNError.message("VPN 连接超时，请查看：\(log.path)")
    }

    func connectWithFeishu() {
        guard !isBusy else { return }
        isBusy = true
        Task {
            defer { isBusy = false }
            do {
                setStatus("正在创建飞书登录请求…", kind: 1)
                let start: DeviceStart = try await json(DeviceStart.self, path: "/api/v1/device/start", body: [:])
                guard let authURL = URL(string: start.auth_url) else { throw VPNError.message("飞书登录地址无效") }
                NSWorkspace.shared.open(authURL)
                setStatus("请在浏览器中确认飞书登录…", kind: 1)
                var authorized: DevicePoll?
                let attempts = max(1, start.expires_in / max(2, start.interval))
                for _ in 0..<attempts {
                    try await Task.sleep(nanoseconds: UInt64(max(2, start.interval)) * 1_000_000_000)
                    do {
                        let poll: DevicePoll = try await json(DevicePoll.self, path: "/api/v1/device/poll", body: ["device_code": start.device_code, "device_verifier": start.device_verifier])
                        if poll.status == "authorized" { authorized = poll; break }
                    } catch let error as VPNError {
                        if error.localizedDescription.contains("拒绝") { throw error }
                    }
                }
                guard let result = authorized, let user = result.username, let token = result.vpn_token else {
                    throw VPNError.message("飞书登录超时，请重新尝试")
                }
                username = user
                UserDefaults.standard.set(user, forKey: "vpnUsername")
                setStatus("正在下载个人 VPN 配置…", kind: 1)
                let (profileData, profileResponse) = try await request(path: "/api/v1/profile/feishu", body: ["device_code": start.device_code, "device_verifier": start.device_verifier])
                guard (200...299).contains(profileResponse.statusCode) else { throw VPNError.message("无法下载个人 VPN 配置") }
                let profile = try installProfile(data: profileData, username: user)
                setStatus("飞书验证成功，正在建立 VPN…", kind: 1)
                let ip = try await connect(username: user, secret: token, profile: profile)
                isConnected = true
                setStatus(ip.isEmpty ? "飞书登录成功" : "飞书登录成功 · VPN IP \(ip)", kind: 2)
            } catch { setStatus(error.localizedDescription, kind: 3) }
        }
    }

    func connectWithAccount() {
        guard !isBusy else { return }
        let user = username.trimmingCharacters(in: .whitespacesAndNewlines)
        let secret = password
        guard !user.isEmpty, !secret.isEmpty else { setStatus("请填写 VPN 账号和密码", kind: 3); return }
        isBusy = true
        Task {
            defer { isBusy = false }
            do {
                UserDefaults.standard.set(user, forKey: "vpnUsername")
                setStatus("正在验证账号并获取个人配置…", kind: 1)
                let (profileData, response) = try await request(path: "/api/v1/profile/account", body: ["username": user, "password": secret])
                guard (200...299).contains(response.statusCode) else { throw VPNError.message("VPN 账号或密码错误") }
                let profile = try installProfile(data: profileData, username: user)
                // TOTP 账号的密码形如「静态密码,6位动态码」，动态码 30 秒即失效；
                // 只把逗号前的静态密码存入钥匙串，下次登录再补 ,动态码。
                if rememberPassword {
                    var saved = secret
                    if let comma = secret.lastIndex(of: ","), comma > secret.startIndex {
                        saved = String(secret[..<comma])
                    }
                    keychainWrite(saved, account: "ldap-password")
                } else { keychainDelete(account: "ldap-password") }
                setStatus("正在建立 VPN…", kind: 1)
                let ip = try await connect(username: user, secret: secret, profile: profile)
                isConnected = true
                setStatus(ip.isEmpty ? "账号登录成功" : "账号登录成功 · VPN IP \(ip)", kind: 2)
            } catch { setStatus(error.localizedDescription, kind: 3) }
        }
    }

    func disconnect() {
        do {
            try stopProcess()
            isConnected = false
            setStatus("VPN 已断开")
        } catch { setStatus(error.localizedDescription, kind: 3) }
    }

    // 点窗口左上角 X 关闭客户端时调用：先断开 VPN，再退出进程。
    // 同步 kill（osascript 等待完成），避免应用退出后 OpenVPN 变成孤儿进程继续占着隧道。
    func disconnectAndTerminate() {
        try? stopProcess()
        isConnected = false
    }

    var hasRunningVPN: Bool { vpnPID != nil }

    private func stopProcess() throws {
        guard let pid = vpnPID else { return }
        let command = "kill \(pid) 2>/dev/null || true"
        _ = try run("/usr/bin/osascript", ["-e", "do shell script \(appleScriptQuote(command)) with administrator privileges"])
        vpnPID = nil
    }

    private func keychainRead(account: String) -> String? {
        var query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        query.removeAll()
        return String(data: data, encoding: .utf8)
    }

    private func keychainWrite(_ value: String, account: String) {
        keychainDelete(account: account)
        let item: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecValueData as String: Data(value.utf8)]
        SecItemAdd(item as CFDictionary, nil)
    }

    private func keychainDelete(account: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
    }
}

struct ContentView: View {
    @StateObject private var model = VPNViewModel.shared
    private let acid = Color(red: 0.76, green: 1.0, blue: 0.11)

    var body: some View {
        ZStack {
            Color(red: 0.04, green: 0.055, blue: 0.06).ignoresSafeArea()
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 22) {
                    if let image = NSImage(named: "KSIcon") {
                        Image(nsImage: image).resizable().scaledToFit().frame(width: 92, height: 92).clipShape(RoundedRectangle(cornerRadius: 20))
                    }
                    VStack(alignment: .leading, spacing: 5) {
                        Text("KSVPN").font(.system(size: 30, weight: .bold, design: .rounded)).foregroundColor(.white)
                        Text("VPN").font(.system(size: 18, weight: .bold)).foregroundColor(acid)
                    }
                }
                Text("企业安全连接  /  自动获取个人配置").foregroundColor(.secondary).padding(.top, 18)
                Divider().overlay(Color.white.opacity(0.15)).padding(.vertical, 26)

                Text("使用飞书身份快速连接").font(.headline).foregroundColor(.white)
                Text("无需输入账号或密码，浏览器验证后自动连接。").foregroundColor(.secondary).padding(.top, 6)
                Button(action: model.connectWithFeishu) {
                    HStack { Text(model.isBusy ? "正在处理…" : "飞书登录并连接").fontWeight(.bold); Spacer(); Text("→") }
                        .padding(.horizontal, 18).frame(height: 52)
                }.buttonStyle(.plain).foregroundColor(.black).background(acid).clipShape(RoundedRectangle(cornerRadius: 10)).disabled(model.isBusy)
                    .padding(.top, 16)

                HStack { Rectangle().frame(height: 1); Text("或使用 LDAP 账号").font(.caption); Rectangle().frame(height: 1) }
                    .foregroundColor(.white.opacity(0.22)).padding(.vertical, 24)

                Text("VPN 账号").font(.caption).foregroundColor(.secondary)
                TextField("例如 wangqiang", text: $model.username).textFieldStyle(.plain).padding(12).background(Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
                Text("VPN 密码").font(.caption).foregroundColor(.secondary).padding(.top, 14)
                SecureField("请输入 LDAP 密码", text: $model.password).textFieldStyle(.plain).padding(12).background(Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
                Toggle("安全记住密码（保存在 macOS 钥匙串）", isOn: $model.rememberPassword).toggleStyle(.checkbox).foregroundColor(.secondary).padding(.top, 14)

                HStack(spacing: 12) {
                    Button("账号登录并连接", action: model.connectWithAccount).buttonStyle(.bordered).controlSize(.large).disabled(model.isBusy)
                    Button("断开 VPN", action: model.disconnect).buttonStyle(.bordered).controlSize(.large).disabled(!model.isConnected)
                }.padding(.top, 18)

                Spacer()
                Text(model.status).font(.callout).foregroundColor(model.statusKind == 2 ? acid : model.statusKind == 3 ? .red : .secondary).lineLimit(2)
            }.padding(36)
        }.frame(width: 520, height: 690)
    }
}

// 点左上角 X 关闭最后一个窗口时：断开 VPN → 退出应用，而不是留在后台保持连接。
private final class VPNAppDelegate: NSObject, NSApplicationDelegate {
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        let model = VPNViewModel.shared
        guard model.hasRunningVPN else { return .terminateNow }
        Task { @MainActor in
            model.disconnectAndTerminate()
            NSApp.reply(toApplicationShouldTerminate: true)
        }
        return .terminateLater
    }
}

@main
struct KSVPNApp: App {
    @NSApplicationDelegateAdaptor(VPNAppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup { ContentView().preferredColorScheme(.dark) }
            .windowResizability(.contentSize)
    }
}
