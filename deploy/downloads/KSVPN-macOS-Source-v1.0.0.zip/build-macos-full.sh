#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
bash "$ROOT/build-macos.sh"

APP="$ROOT/build/KSVPN.app"
MACOS="$APP/Contents/MacOS"
FRAMEWORKS="$APP/Contents/Frameworks"
OPENVPN="$(command -v openvpn || true)"

if [[ -z "$OPENVPN" ]]; then
  echo "OpenVPN is required only on the build Mac. Install it with: brew install openvpn" >&2
  exit 1
fi

mkdir -p "$FRAMEWORKS"
cp "$OPENVPN" "$MACOS/openvpn"

queue=("$MACOS/openvpn")
seen=""
while ((${#queue[@]})); do
  binary="${queue[0]}"
  queue=("${queue[@]:1}")
  while IFS= read -r dependency; do
    [[ "$dependency" == /opt/homebrew/* || "$dependency" == /usr/local/* ]] || continue
    base="$(basename "$dependency")"
    if [[ "$seen" != *"|$base|"* ]]; then
      cp -L "$dependency" "$FRAMEWORKS/$base"
      chmod u+w "$FRAMEWORKS/$base"
      install_name_tool -id "@executable_path/../Frameworks/$base" "$FRAMEWORKS/$base" || true
      queue+=("$FRAMEWORKS/$base")
      seen="$seen|$base|"
    fi
    install_name_tool -change "$dependency" "@executable_path/../Frameworks/$base" "$binary"
  done < <(otool -L "$binary" | tail -n +2 | awk '{print $1}')
done

find "$FRAMEWORKS" -type f -exec codesign --force --sign - {} \;
codesign --force --sign - "$MACOS/openvpn"
codesign --force --deep --sign - "$APP"

mv "$APP" "$ROOT/build/KSVPN Full.app"
echo "$ROOT/build/KSVPN Full.app"
