import AppKit
import Foundation

// Track only the dedicated Chrome tab created for this authentication attempt.
// Do not inspect its URL after opening it or read page contents or credentials.
@MainActor
final class AuthenticationBrowser {
    private var windowID: Int?
    private var tabID: Int?

    func open(_ url: URL) async throws {
        guard NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.google.Chrome") != nil else {
            throw VPNError.message("此测试版需要 Google Chrome 来监测认证窗口关闭，请先安装 Chrome")
        }
        let script = """
        tell application "Google Chrome"
            activate
            set authWindow to make new window
            set URL of active tab of authWindow to \(browserQuote(url.absoluteString))
            return (id of authWindow as text) & ":" & (id of active tab of authWindow as text)
        end tell
        """
        let result = try await browserScript(script)
        let ids = result.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ":")
        guard ids.count == 2, let w = Int(ids[0]), let t = Int(ids[1]) else {
            throw VPNError.message("无法跟踪飞书认证窗口，请重新点击飞书登录")
        }
        windowID = w
        tabID = t
    }

    func isOpen() async throws -> Bool {
        guard let windowID, let tabID else { return false }
        let script = """
        if application "Google Chrome" is not running then return "closed"
        tell application "Google Chrome"
            if not (exists window id \(windowID)) then return "closed"
            if not (exists tab id \(tabID) of window id \(windowID)) then return "closed"
            return "open"
        end tell
        """
        return try await browserScript(script).trimmingCharacters(in: .whitespacesAndNewlines) == "open"
    }

    func close() async {
        guard let windowID, let tabID else { return }
        release()
        let script = """
        if application "Google Chrome" is running then
            tell application "Google Chrome"
                if exists window id \(windowID) then
                    if exists tab id \(tabID) of window id \(windowID) then close (tab id \(tabID) of window id \(windowID))
                end if
            end tell
        end if
        """
        _ = try? await browserScript(script)
    }

    func release() { windowID = nil; tabID = nil }
}

private func browserQuote(_ value: String) -> String {
    "\"" + value.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
}

private func browserScript(_ script: String) async throws -> String {
    try await Task.detached(priority: .userInitiated) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        let input = Pipe(), output = Pipe()
        process.standardInput = input
        process.standardOutput = output
        process.standardError = output
        try process.run()
        // Send the login URL through stdin, never command-line arguments or logs.
        input.fileHandleForWriting.write(Data(script.utf8))
        try? input.fileHandleForWriting.close()
        let deadline = ProcessInfo.processInfo.systemUptime + 8
        while process.isRunning && ProcessInfo.processInfo.systemUptime < deadline {
            try await Task.sleep(nanoseconds: 50_000_000)
        }
        if process.isRunning {
            process.terminate()
            process.waitUntilExit()
            throw VPNError.message("无法访问认证窗口，请允许客户端控制 Chrome 后重试")
        }
        let data = output.fileHandleForReading.readDataToEndOfFile()
        guard process.terminationStatus == 0 else {
            throw VPNError.message("无法监测认证窗口，请在 macOS 隐私与安全性 → 自动化中允许访问 Chrome")
        }
        return String(data: data, encoding: .utf8) ?? ""
    }.value
}
