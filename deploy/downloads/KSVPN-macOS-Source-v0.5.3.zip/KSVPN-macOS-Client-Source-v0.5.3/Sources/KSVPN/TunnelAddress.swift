import Foundation
import Darwin

enum TunnelAddress {
    static func interfaceName(in log: String) -> String? {
        capture(#"Opened utun device (utun\d+)"#, in: log)
            ?? capture(#"ifconfig\s+((?:utun|tun)\d+)\s+\d{1,3}\."#, in: log)
    }

    static func ipv4(in log: String) -> String {
        if let name = interfaceName(in: log), let address = interfaceIPv4(name) { return address }
        let address = capture(#"ifconfig\s+(?:utun|tun)\d+\s+(\d{1,3}(?:\.\d{1,3}){3})\s"#, in: log)
            ?? capture(#"(?:,|\s)ifconfig\s+(\d{1,3}(?:\.\d{1,3}){3})\s"#, in: log)
        guard let address, address.split(separator: ".").count == 4,
              address.split(separator: ".").allSatisfy({ UInt8($0) != nil }) else { return "" }
        return address
    }

    private static func capture(_ pattern: String, in text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).last,
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }

    private static func interfaceIPv4(_ name: String) -> String? {
        var list: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&list) == 0, let first = list else { return nil }
        defer { freeifaddrs(first) }
        var current: UnsafeMutablePointer<ifaddrs>? = first
        while let item = current {
            defer { current = item.pointee.ifa_next }
            guard String(cString: item.pointee.ifa_name) == name,
                  let address = item.pointee.ifa_addr,
                  address.pointee.sa_family == UInt8(AF_INET) else { continue }
            var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(address, socklen_t(address.pointee.sa_len), &buffer,
                           socklen_t(buffer.count), nil, 0, NI_NUMERICHOST) == 0 {
                return String(cString: buffer)
            }
        }
        return nil
    }
}
