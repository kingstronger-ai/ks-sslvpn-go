import Foundation
@preconcurrency import Security
@preconcurrency import XPC
import Darwin

private struct ServiceResponse: Sendable {
    let ok: Bool
    let version: String
    let phase: String
    let ip: String
    let error: String
}

private final class ServiceReply: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<ServiceResponse, Error>?
    init(_ continuation: CheckedContinuation<ServiceResponse, Error>) { self.continuation = continuation }
    func resolve(_ result: Result<ServiceResponse, Error>) {
        lock.lock(); let value = continuation; continuation = nil; lock.unlock()
        value?.resume(with: result)
    }
}

@MainActor
final class PrivilegedVPNClient {
    private var connection: xpc_connection_t?
    private var requirement: SecRequirement?
    private var unavailable: VPNError { .message("VPN 后台服务不可用，请先使用全量安装包完成首次安装与授权") }

    private func installedConnection() throws -> (xpc_connection_t, SecRequirement) {
        if let connection, let requirement { return (connection, requirement) }
        let path = "/Library/Application Support/KSVPN/Service/helper-requirement.txt"
        var info = stat()
        guard lstat(path, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG,
              info.st_uid == 0, (info.st_mode & 0o022) == 0,
              let text = try? String(contentsOfFile: path, encoding: .utf8).trimmingCharacters(in: .whitespacesAndNewlines),
              text.hasPrefix("cdhash H\""), text.hasSuffix("\"") else { throw unavailable }
        let required = try SecureXPC.requirement(text)
        let value = xpc_connection_create_mach_service(vpnMachService, DispatchQueue.global(), UInt64(XPC_CONNECTION_MACH_SERVICE_PRIVILEGED))
        xpc_connection_set_event_handler(value) { _ in }
        xpc_connection_resume(value)
        self.connection = value; self.requirement = required
        return (value, required)
    }

    private func request(_ operation: String, profile: Data? = nil, username: String = "", secret: String = "") async throws -> ServiceResponse {
        let (connection, requirement) = try installedConnection()
        let failure = unavailable
        let message = xpc_dictionary_create(nil, nil, 0)
        xpc_dictionary_set_string(message, "op", operation)
        if let profile { profile.withUnsafeBytes { xpc_dictionary_set_data(message, "profile", $0.baseAddress, $0.count) } }
        if operation == "start" {
            xpc_dictionary_set_string(message, "username", username)
            xpc_dictionary_set_string(message, "secret", secret)
        }
        return try await withCheckedThrowingContinuation { continuation in
            let gate = ServiceReply(continuation)
            DispatchQueue.global().asyncAfter(deadline: .now() + 8) { gate.resolve(.failure(failure)) }
            xpc_connection_send_message_with_reply(connection, message, DispatchQueue.global()) { response in
                // A system Mach service plus mandatory root UID and code identity checks.
                guard xpc_connection_get_euid(connection) == 0,
                      SecureXPC.authenticates(response, requirement: requirement) else {
                    gate.resolve(.failure(failure)); return
                }
                gate.resolve(.success(ServiceResponse(ok: xpc_dictionary_get_bool(response, "ok"),
                    version: SecureXPC.string(response, "version"), phase: SecureXPC.string(response, "phase"),
                    ip: SecureXPC.string(response, "ip"), error: SecureXPC.string(response, "error"))))
            }
        }
    }

    func invalidate() {
        if let connection { xpc_connection_cancel(connection) }
        connection = nil; requirement = nil
    }

    func ensureAvailable() async throws {
        let response = try await request("ping")
        guard response.ok, response.version == "1" else { throw VPNError.message("VPN 后台服务版本不匹配，请运行升级安装包") }
    }
    func start(profile: Data, username: String, secret: String) async throws {
        let response = try await request("start", profile: profile, username: username, secret: secret)
        guard response.ok else { throw VPNError.message(response.error.isEmpty ? "VPN 启动失败" : response.error) }
    }
    func status() async throws -> (phase: String, ip: String, error: String) {
        let response = try await request("status")
        guard response.ok else { throw unavailable }
        return (response.phase, response.ip, response.error)
    }
    func stop() async throws {
        let response = try await request("stop")
        guard response.ok else { throw unavailable }
    }
}
