import Foundation
struct AuthenticationLifecycle {
    enum State { case waiting, authorized, cancelled, timedOut }
    let deadline: TimeInterval
    private(set) var state: State = .waiting
    mutating func observe(serverStatus: String?, browserOpen: Bool, now: TimeInterval) {
        guard state == .waiting else { return }
        if now >= deadline { state = .timedOut; return }
        if serverStatus == "authorized" { state = .authorized; return }
        if let serverStatus, ["denied", "rejected", "expired", "cancelled"].contains(serverStatus) { state = .cancelled; return }
        if !browserOpen { state = .cancelled }
    }
}
