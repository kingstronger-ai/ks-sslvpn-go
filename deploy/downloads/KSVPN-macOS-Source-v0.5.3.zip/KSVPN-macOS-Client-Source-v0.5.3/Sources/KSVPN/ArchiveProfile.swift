import Foundation

enum ArchiveProfile {
    static func read(_ archive: URL) throws -> Data {
        let listing = try command(["-tzf", archive.path], limit: 64 * 1024)
        guard let names = String(data: listing, encoding: .utf8) else { throw VPNError.message("配置包目录编码无效") }
        let entries = names.split(separator: "\n").map(String.init)
        guard !entries.isEmpty, entries.count <= 100 else { throw VPNError.message("配置包内容数量异常") }
        for path in entries {
            guard !path.hasPrefix("/"), !path.contains("\\"),
                  !path.split(separator: "/").contains(".."),
                  !path.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
                throw VPNError.message("配置包包含不安全路径")
            }
        }
        let verbose = try command(["-tvzf", archive.path], limit: 128 * 1024)
        guard let details = String(data: verbose, encoding: .utf8),
              details.split(separator: "\n").allSatisfy({ $0.first == "-" || $0.first == "d" }) else {
            throw VPNError.message("配置包包含不支持的链接或特殊文件")
        }
        let candidates = entries.filter { $0.lowercased().hasSuffix(".ovpn") }
        guard candidates.count == 1 else { throw VPNError.message("配置包中没有唯一的个人 VPN 配置") }
        // Stream one regular file into memory; never extract archive members onto disk.
        return try command(["-xOzf", archive.path, "--", candidates[0]], limit: 1_048_576)
    }

    private static func command(_ arguments: [String], limit: Int) throws -> Data {
        let process = Process(), pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/tar")
        process.arguments = arguments
        process.standardOutput = pipe
        process.standardError = FileHandle.nullDevice
        try process.run()
        var result = Data()
        while true {
            let block = pipe.fileHandleForReading.readData(ofLength: 16_384)
            if block.isEmpty { break }
            if result.count + block.count > limit {
                process.terminate(); try? pipe.fileHandleForReading.close(); process.waitUntilExit()
                throw VPNError.message("个人配置包超出允许大小")
            }
            result.append(block)
        }
        process.waitUntilExit()
        guard process.terminationStatus == 0 else { throw VPNError.message("个人配置包读取失败") }
        return result
    }
}
