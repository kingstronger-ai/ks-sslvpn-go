import AppKit
import SwiftUI

@MainActor
final class VPNApplicationDelegate: NSObject, NSApplicationDelegate {
    private var quitTask: Task<Void, Never>?
    private var watchdog: Task<Void, Never>?
    private var attempt: UUID?

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        WindowClosePresenter.shared.restoreWindow()
        return true
    }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard let model = WindowClosePresenter.shared.model else { return .terminateNow }
        if model.canTerminate { return .terminateNow }
        guard attempt == nil else { return .terminateCancel }
        let id = UUID()
        attempt = id
        WindowClosePresenter.shared.showQuitProgress { [weak self] in self?.forceQuit() }
        // Do not enter AppKit's terminateLater loop: it can prevent MainActor
        // cleanup from running. Finish cleanup in the normal application loop.
        quitTask = Task { [weak self] in
            let stopped = await model.prepareToQuit()
            guard let self, self.attempt == id else { return }
            self.attempt = nil
            self.watchdog?.cancel()
            WindowClosePresenter.shared.dismissQuitProgress()
            if stopped { sender.terminate(nil) }
            else { self.showFailure() }
        }
        watchdog = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 30_000_000_000) } catch { return }
            guard let self, self.attempt == id else { return }
            self.attempt = nil
            self.quitTask?.cancel()
            model.cancelQuitWaiting()
            WindowClosePresenter.shared.dismissQuitProgress()
            self.showFailure()
        }
        return .terminateCancel
    }

    private func showFailure() {
        WindowClosePresenter.shared.showStopError { [weak self] in self?.forceQuit() }
    }

    private func forceQuit() {
        attempt = nil
        watchdog?.cancel()
        quitTask?.cancel()
        WindowClosePresenter.shared.model?.forceQuit()
        WindowClosePresenter.shared.dismissQuitProgress()
        NSApplication.shared.terminate(nil)
    }
}

@MainActor
final class WindowClosePresenter: NSObject {
    static let shared = WindowClosePresenter()
    weak var model: VPNViewModel?
    private     weak var window: NSWindow?
    private var proxy: WindowCloseDelegateProxy?
    private var quitProgress: NSAlert?

    func attach(_ window: NSWindow, model: VPNViewModel) {
        self.window = window
        self.model = model
        guard window.delegate !== proxy else { return }
        let value = WindowCloseDelegateProxy(original: window.delegate)
        proxy = value
        window.delegate = value
    }

    func restoreWindow() {
        window?.deminiaturize(nil)
        window?.makeKeyAndOrderFront(nil)
    }

    func showQuitProgress(force: @escaping @MainActor () -> Void) {
        restoreWindow()
        let alert = NSAlert()
        alert.messageText = "正在断开 VPN 并退出…"
        alert.informativeText = "正在结束登录和 VPN 连接，请稍候。若长时间没有完成，可选择强制退出；后台服务将继续清理本客户端的连接。"
        alert.addButton(withTitle: "强制退出")
        alert.buttons[0].keyEquivalent = ""
        quitProgress = alert
        if let window {
            alert.beginSheetModal(for: window) { [weak self] response in
                guard self?.quitProgress === alert else { return }
                self?.quitProgress = nil
                if response == .alertFirstButtonReturn { force() }
            }
        }
    }

    func dismissQuitProgress() {
        guard let alert = quitProgress else { return }
        quitProgress = nil
        if let parent = alert.window.sheetParent { parent.endSheet(alert.window, returnCode: .abort) }
        alert.window.orderOut(nil)
    }

    func showStopError(force: @escaping @MainActor () -> Void) {
        restoreWindow()
        let alert = NSAlert()
        alert.messageText = "暂未确认 VPN 已断开"
        alert.informativeText = "已停止等待退出。你可以留在客户端重试，或强制退出，让后台服务继续清理本客户端的连接。"
        alert.addButton(withTitle: "返回客户端")
        alert.addButton(withTitle: "强制退出")
        alert.buttons[1].keyEquivalent = ""
        if let window {
            alert.beginSheetModal(for: window) { response in
                if response == .alertSecondButtonReturn { force() }
            }
        }
    }

}

// Forward SwiftUI's other window delegate callbacks instead of replacing its lifecycle behavior.
final class WindowCloseDelegateProxy: NSObject, NSWindowDelegate {
    nonisolated(unsafe) private weak var original: NSWindowDelegate?
    init(original: NSWindowDelegate?) { self.original = original }

    @MainActor func windowShouldClose(_ sender: NSWindow) -> Bool {
        // Clicking the close (red) button disconnects the VPN and quits the client
        // directly. When the model is already in a terminal state the window may close
        // on its own; otherwise hand off to the app delegate's terminate flow, which
        // disconnects the tunnel and then exits the process.
        if WindowClosePresenter.shared.model?.canTerminate == true { return true }
        NSApplication.shared.terminate(nil)
        return false
    }

    nonisolated override func responds(to selector: Selector!) -> Bool {
        super.responds(to: selector) || original?.responds(to: selector) == true
    }

    nonisolated override func forwardingTarget(for selector: Selector!) -> Any? {
        if original?.responds(to: selector) == true { return original }
        return super.forwardingTarget(for: selector)
    }
}

struct WindowCloseBehavior: NSViewRepresentable {
    let model: VPNViewModel
    func makeNSView(context: Context) -> Host {
        let view = Host()
        view.model = model
        return view
    }
    func updateNSView(_ nsView: Host, context: Context) {
        nsView.model = model
        nsView.attach()
    }
    final class Host: NSView {
        weak var model: VPNViewModel?
        override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); attach() }
        func attach() {
            guard let window, let model else { return }
            WindowClosePresenter.shared.attach(window, model: model)
        }
    }
}
