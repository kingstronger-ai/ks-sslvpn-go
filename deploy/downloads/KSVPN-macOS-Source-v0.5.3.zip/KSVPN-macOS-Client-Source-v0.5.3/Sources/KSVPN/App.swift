import Foundation
import SwiftUI
import AppKit
import Security

// 默认认证网关：对齐重构后的 sslvpn-go 管理端口 58443，不保留旧网关的 /feishu-sso 后缀。
// 换服务器（含端口）无需重新编译：在 ~/Library/Application Support/KSVPN/gateway.txt
// 写一行地址即可覆盖，例如 https://vpn.example.com:58443
private let defaultGateway = "https://vpn.kingstronger.com:58443"
private let gateway: String = {
    let path = NSHomeDirectory() + "/Library/Application Support/KSVPN/gateway.txt"
    if let raw = try? String(contentsOfFile: path, encoding: .utf8) {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if (value.hasPrefix("https://") || value.hasPrefix("http://")),
           !value.contains("\n"), !value.contains("\r"), !value.contains(" ") {
            return value
        }
    }
    return defaultGateway
}()

private struct DeviceStart: Decodable {
    let device_code: String
    let device_verifier: String
    let auth_url: String
    let expires_in: Int
    let interval: Int
}

private struct DevicePoll: Decodable {
    let status: String
    let username: String?
    let vpn_token: String?
    let error: String?
}

enum VPNError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let text) = self { return text }
        return "未知错误"
    }
}

private func run(_ executable: String, _ arguments: [String]) throws -> String {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: executable)
    process.arguments = arguments
    let pipe = Pipe()
    process.standardOutput = pipe
    process.standardError = pipe
    try process.run()
    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    process.waitUntilExit()
    let output = String(data: data, encoding: .utf8) ?? ""
    if process.terminationStatus != 0 { throw VPNError.message(output.isEmpty ? "命令执行失败" : output) }
    return output.trimmingCharacters(in: .whitespacesAndNewlines)
}

@MainActor
final class VPNViewModel: ObservableObject {
    @Published var username = UserDefaults.standard.string(forKey: "vpnUsername") ?? ""
    @Published var password = ""
    @Published var otpCode = ""
    @Published var rememberPassword = false
    @Published var status = "准备就绪"
    @Published var statusKind = 0
    @Published var isBusy = false
    @Published var isConnected = false
    @Published private(set) var isQuitting = false
    private(set) var canTerminate = false
    @Published var vpnIP = ""
    @Published var authSecondsRemaining: Int?
    private let authenticationBrowser = AuthenticationBrowser()

    private let vpnService = PrivilegedVPNClient()
    private var vpnMonitor: Task<Void, Never>?
    private var loginTask: Task<Void, Never>?
    private var mayHaveVPNSession = false
    private var previousServiceState = ""
    private var serviceHistory: [String] = []
    private let fm = FileManager.default
    private let service = "tech.ksvpn.vpn"

    init() {
        if let saved = keychainRead(account: "ldap-password") {
            password = saved
            rememberPassword = true
        }
    }

    private var appDir: URL {
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("KSVPN", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        try? fm.setAttributes([.posixPermissions: 0o700], ofItemAtPath: dir.path)
        return dir
    }

    private func setStatus(_ text: String, kind: Int = 0) {
        status = text
        statusKind = kind
    }

    private func request(path: String, body: [String: String], timeout: TimeInterval = 30) async throws -> (Data, HTTPURLResponse) {
        guard let url = URL(string: gateway + path) else { throw VPNError.message("认证网关地址无效") }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = timeout
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: req)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw VPNError.message("认证网关响应无效") }
        return (data, http)
    }

    private func json<T: Decodable>(_ type: T.Type, path: String, body: [String: String], timeout: TimeInterval = 30) async throws -> T {
        let (data, response) = try await request(path: path, body: body, timeout: timeout)
        if !(200...299).contains(response.statusCode) {
            let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
            throw VPNError.message(object?["error"] as? String ?? "认证网关拒绝请求")
        }
        return try JSONDecoder().decode(type, from: data)
    }

    private func installProfile(data: Data, username: String) throws -> URL {
        guard username.range(of: #"^[A-Za-z0-9_.-]{1,64}$"#, options: .regularExpression) != nil else {
            throw VPNError.message("服务端返回的 VPN 账号格式不正确")
        }
        guard data.count <= 2_097_152 else { throw VPNError.message("个人配置包超出允许大小") }
        let archive = appDir.appendingPathComponent("profile-\(UUID().uuidString).tgz")
        defer { try? fm.removeItem(at: archive) }
        guard fm.createFile(atPath: archive.path, contents: data, attributes: [.posixPermissions: 0o600]) else {
            throw VPNError.message("无法保存个人配置包")
        }
        let tuned = Self.tuneHeartbeat(try ArchiveProfile.read(archive))
        let profileDir = appDir.appendingPathComponent("profiles", isDirectory: true)
        try fm.createDirectory(at: profileDir, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        try fm.setAttributes([.posixPermissions: 0o700], ofItemAtPath: profileDir.path)
        let destination = profileDir.appendingPathComponent("\(username).ovpn")
        guard fm.createFile(atPath: destination.path, contents: tuned, attributes: [.posixPermissions: 0o600]) else {
            throw VPNError.message("无法保存个人 VPN 配置")
        }
        return destination
    }

    /// 服务端下发的 .ovpn 默认 `reneg-sec 0`（永不重认证）且不含任何 ping 心跳，
    /// 管理员后台「踢下线」后，客户端实测要等约 5 分钟才察觉。
    /// Helper 的 ovpn 指令白名单允许 ping / ping-restart / explicit-exit-notify，
    /// 这里在写盘前补上心跳：服务端停止回应后约 20 秒即触发重连与失败上报。
    private static func tuneHeartbeat(_ data: Data) -> Data {
        guard let text = String(data: data, encoding: .utf8) else { return data }
        let controlled = ["ping", "ping-restart", "ping-timer-rem", "keepalive", "explicit-exit-notify"]
        var lines = text.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        lines.removeAll { line in
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            return controlled.contains { trimmed == $0 || trimmed.hasPrefix($0 + " ") || trimmed.hasPrefix($0 + "\t") }
        }
        while lines.last?.trimmingCharacters(in: .whitespaces).isEmpty == true { lines.removeLast() }
        lines.append(contentsOf: [
            "",
            "# KSVPN: 缩短服务端断开的感知时间（Helper 白名单内指令）",
            "ping 5",
            "ping-restart 20",
            "explicit-exit-notify 3"
        ])
        return Data((lines.joined(separator: "\n") + "\n").utf8)
    }

    /// Helper 把 openvpn 的 AUTH_FAILED 统一翻成「账号或密码错误，服务器拒绝登录」。
    /// 实测同一条文案既出现在「首次认证密码/动态码错误」，也出现在「已连接后被管理员踢下线」，
    /// 且后者重新认证即可照常使用。两种场景必须分开描述，否则用户会误以为密码被改了。
    private static func isAuthFailedText(_ raw: String) -> Bool {
        raw.contains("账号或密码错误") || raw.contains("服务器拒绝登录")
    }

    private static func describeLoginFailure(_ raw: String) -> String {
        if raw.isEmpty { return "VPN 连接已结束，请重新连接" }
        return isAuthFailedText(raw) ? "服务端拒绝了本次认证，请核对 VPN 密码或动态码后重试" : raw
    }

    /// 服务端自 v1.2.8 起用 `client-kill <CID> HALT` 强制下线：HALT 是控制消息，
    /// 不是 AUTH_FAILED，引擎退出后 Helper 的日志分类没命中认证失败分支，
    /// 会落到兜底文案「个人 VPN 配置与引擎不兼容」（实测连接后约 10 秒出现）。
    /// 这句只在「已连接后断开」场景透出，必须归为被踢，否则用户会误以为配置损坏。
    /// 注意：首次连接失败仍走 describeLoginFailure，真正的配置不兼容不会被掩盖。
    private static func isKickText(_ raw: String) -> Bool {
        isAuthFailedText(raw)
            || raw.contains("个人 VPN 配置与引擎不兼容")
            || raw.contains("VPN 进程已结束")
    }

    private static func describeKickFailure(_ raw: String) -> String {
        if isKickText(raw) {
            return "连接已被服务器中断（可能被管理员强制下线），重新点击「账号登录并连接」即可恢复使用"
        }
        return raw.isEmpty ? "VPN 已断开" : raw
    }

    private func connect(username: String, secret: String, profile: URL) async throws -> String {
        try Task.checkCancellation()
        mayHaveVPNSession = true
        try await vpnService.start(profile: Data(contentsOf: profile), username: username, secret: secret)
        try Task.checkCancellation()
        for _ in 0..<95 {
            try await Task.sleep(nanoseconds: 1_000_000_000)
            let state = try await vpnService.status()
            recordServiceState(state.phase, ip: state.ip, error: state.error)
            if state.phase == "connected" { return state.ip }
            if ["failed", "idle", "busy"].contains(state.phase) {
                // 动态码是一次性的，失败后必须重填；静态密码与钥匙串保留，
                // 避免「被踢下线 / 限流 / 服务端误报」时误删用户已保存的凭据。
                if !otpCode.isEmpty { otpCode = "" }
                throw VPNError.message(Self.describeLoginFailure(state.error))
            }
        }
        try? await vpnService.stop()
        throw VPNError.message("VPN 连接超时，请检查网络后重试")
    }

    private func recordServiceState(_ phase: String, ip: String, error: String) {
        let value = [phase, ip, error].joined(separator: " | ")
        guard value != previousServiceState else { return }
        previousServiceState = value
        serviceHistory.append(ISO8601DateFormatter().string(from: Date()) + " " + value)
        serviceHistory = Array(serviceHistory.suffix(60))
        let data = Data(serviceHistory.joined(separator: "\n").utf8)
        _ = fm.createFile(atPath: appDir.appendingPathComponent("connection-status.log").path, contents: data, attributes: [.posixPermissions: 0o600])
    }

    private func monitorConnection() {
        vpnMonitor?.cancel()
        vpnMonitor = Task { [weak self] in
            guard let self else { return }
            while self.isConnected && !Task.isCancelled {
                do {
                    try await Task.sleep(nanoseconds: 1_000_000_000)
                    let state = try await self.vpnService.status()
                    self.recordServiceState(state.phase, ip: state.ip, error: state.error)
                    if state.phase == "connected" {
                        self.vpnIP = state.ip
                    } else {
                        self.isConnected = false; self.vpnIP = ""; self.mayHaveVPNSession = false
                        let interrupted = state.phase == "failed"
                        self.setStatus(interrupted ? Self.describeKickFailure(state.error) : "VPN 已断开",
                                       kind: 1)
                        // 清理后台服务侧残留状态，避免下次连接被判定为 busy。
                        Task { try? await self.vpnService.stop() }
                    }
                } catch is CancellationError { return }
                catch {
                    self.isConnected = false; self.vpnIP = ""
                    self.setStatus("与 VPN 后台服务的连接已中断", kind: 3)
                }
            }
        }
    }

    func connectWithFeishu() {
        guard !isBusy, !isConnected, !isQuitting else { return }
        isBusy = true
        loginTask = Task {
            var awaitingAuthentication = true
            defer { isBusy = false; authSecondsRemaining = nil; loginTask = nil }
            do {
                try await vpnService.ensureAvailable()
                setStatus("正在创建飞书登录请求…", kind: 1)
                let start: DeviceStart = try await json(DeviceStart.self, path: "/api/v1/device/start", body: [:])
                guard let authURL = URL(string: start.auth_url), authURL.scheme == "https" else {
                    throw VPNError.message("飞书登录地址无效")
                }
                let duration = min(120, max(1, start.expires_in))
                let deadline = ProcessInfo.processInfo.systemUptime + Double(duration)
                authSecondsRemaining = duration
                setStatus("请在浏览器中完成飞书验证；关闭认证窗口将取消登录", kind: 1)
                try await authenticationBrowser.open(authURL)
                try Task.checkCancellation()
                var authorized: DevicePoll?
                var lifecycle = AuthenticationLifecycle(deadline: deadline)
                var nextPoll = ProcessInfo.processInfo.systemUptime
                var nextWindowCheck = nextPoll
                while ProcessInfo.processInfo.systemUptime < deadline {
                    try Task.checkCancellation()
                    let now = ProcessInfo.processInfo.systemUptime
                    authSecondsRemaining = max(0, Int(ceil(deadline - now)))
                    if now >= nextPoll {
                        do {
                            let remaining = max(1, min(8, deadline - now))
                            let poll: DevicePoll = try await json(DevicePoll.self, path: "/api/v1/device/poll", body: ["device_code": start.device_code, "device_verifier": start.device_verifier], timeout: remaining)
                            guard ProcessInfo.processInfo.systemUptime < deadline else { break }
                            lifecycle.observe(serverStatus: poll.status, browserOpen: true, now: ProcessInfo.processInfo.systemUptime)
                            if lifecycle.state == .authorized { authorized = poll; break }
                            if ["denied", "rejected", "expired", "cancelled"].contains(poll.status) {
                                throw VPNError.message("飞书认证已取消或过期，请重新点击飞书登录")
                            }
                        } catch let error as VPNError {
                            throw error
                        } catch is CancellationError {
                            throw CancellationError()
                        } catch {
                            // A transient polling network failure does not create a new login request.
                        }
                        nextPoll = ProcessInfo.processInfo.systemUptime + Double(max(2, start.interval))
                    }
                    if ProcessInfo.processInfo.systemUptime >= nextWindowCheck {
                        if try await !authenticationBrowser.isOpen() {
                            let graceDeadline = min(deadline, ProcessInfo.processInfo.systemUptime + 6)
                            setStatus("正在确认飞书认证结果…", kind: 1)
                            while ProcessInfo.processInfo.systemUptime < graceDeadline {
                                try Task.checkCancellation()
                                let remaining = max(0.2, min(2, graceDeadline - ProcessInfo.processInfo.systemUptime))
                                let confirmation: DevicePoll? = try? await json(DevicePoll.self, path: "/api/v1/device/poll", body: ["device_code": start.device_code, "device_verifier": start.device_verifier], timeout: remaining)
                                lifecycle.observe(serverStatus: confirmation?.status, browserOpen: true, now: ProcessInfo.processInfo.systemUptime)
                                if lifecycle.state == .authorized, let confirmation { authorized = confirmation; break }
                                if lifecycle.state != .waiting { break }
                                let pause = min(Double(max(2, start.interval)), max(0, graceDeadline - ProcessInfo.processInfo.systemUptime))
                                try await Task.sleep(nanoseconds: UInt64(pause * 1_000_000_000))
                            }
                            if authorized != nil { break }
                            lifecycle.observe(serverStatus: nil, browserOpen: false, now: ProcessInfo.processInfo.systemUptime)
                            throw VPNError.message(lifecycle.state == .timedOut ? "飞书认证等待已超时，请重新点击飞书登录" : "认证窗口已关闭，本次登录已取消；请重新点击飞书登录")
                        }
                        nextWindowCheck = ProcessInfo.processInfo.systemUptime + 1
                    }
                    try await Task.sleep(nanoseconds: 250_000_000)
                }
                guard let result = authorized, let user = result.username, let token = result.vpn_token else {
                    throw VPNError.message("飞书认证等待已超时，本次登录已取消；请重新点击飞书登录")
                }
                // Authentication is complete. Closing this browser tab must no longer affect the VPN.
                awaitingAuthentication = false
                authSecondsRemaining = nil
                await authenticationBrowser.close()
                username = user
                UserDefaults.standard.set(user, forKey: "vpnUsername")
                setStatus("正在下载个人 VPN 配置…", kind: 1)
                let (profileData, profileResponse) = try await request(path: "/api/v1/profile/feishu", body: ["device_code": start.device_code, "device_verifier": start.device_verifier])
                guard (200...299).contains(profileResponse.statusCode) else { throw VPNError.message("无法下载个人 VPN 配置") }
                let profile = try installProfile(data: profileData, username: user)
                setStatus("飞书验证成功，正在建立 VPN…", kind: 1)
                let ip = try await connect(username: user, secret: token, profile: profile)
                vpnIP = ip
                isConnected = true
                monitorConnection()
                setStatus("飞书登录成功", kind: 2)
            } catch {
                if awaitingAuthentication { await authenticationBrowser.close() }
                setStatus(error is CancellationError ? "本次登录已取消，请重新点击飞书登录" : error.localizedDescription, kind: 3)
            }
        }
    }

    func connectWithAccount() {
        guard !isBusy, !isConnected, !isQuitting else { return }
        let user = username.trimmingCharacters(in: .whitespacesAndNewlines)
        let secret = password
        guard !user.isEmpty, !secret.isEmpty else { setStatus("请填写 VPN 账号和密码", kind: 3); return }
        isBusy = true
        loginTask = Task {
            defer { isBusy = false; loginTask = nil }
            do {
                try await vpnService.ensureAvailable()
                UserDefaults.standard.set(user, forKey: "vpnUsername")
                setStatus("正在验证账号并获取个人配置…", kind: 1)
                // 线上网关对 TOTP 账号在「下载个人配置」这一步即校验动态码，
                // 密码须按「静态密码,动态码」提交（与 Windows 客户端一致）。
                // 用户若已按 Windows 习惯在密码框里带了逗号，则不再重复拼接。
                let otp = otpCode.trimmingCharacters(in: .whitespaces)
                let connectSecret = (otp.isEmpty || secret.contains(",")) ? secret : secret + "," + otp
                var result = try await request(path: "/api/v1/profile/account", body: ["username": user, "password": connectSecret])
                // 兼容「只校验静态密码」的旧版网关：带动态码被 401 时回退重试一次。
                if result.1.statusCode == 401 && connectSecret != secret {
                    result = try await request(path: "/api/v1/profile/account", body: ["username": user, "password": secret])
                }
                let (profileData, response) = result
                guard (200...299).contains(response.statusCode) else {
                    let object = try? JSONSerialization.jsonObject(with: profileData) as? [String: Any]
                    let serverMsg = object?["error"] as? String
                    let detail: String
                    switch response.statusCode {
                    case 429: detail = serverMsg ?? "请求过于频繁，请等待 1 分钟后再试"
                    case 401: detail = serverMsg ?? "VPN 账号、密码或动态码错误"
                    default:  detail = serverMsg ?? "验证失败（HTTP \(response.statusCode)）"
                    }
                    throw VPNError.message(detail)
                }
                let profile = try installProfile(data: profileData, username: user)
                setStatus("正在建立 VPN…", kind: 1)
                let ip = try await connect(username: user, secret: connectSecret, profile: profile)
                if rememberPassword { keychainWrite(secret, account: "ldap-password") } else { keychainDelete(account: "ldap-password") }
                vpnIP = ip
                isConnected = true
                monitorConnection()
                setStatus("账号登录成功", kind: 2)
            } catch { setStatus(error.localizedDescription, kind: 3) }
        }
    }

    func disconnect() {
        guard !isBusy, !isQuitting else { return }
        isBusy = true
        Task {
            defer { isBusy = false }
            do {
                try await vpnService.stop()
                setStatus("正在断开 VPN…", kind: 1)
                for _ in 0..<12 {
                    let state = try await vpnService.status()
                    if ["idle", "failed"].contains(state.phase) {
                        vpnMonitor?.cancel()
                        isConnected = false; vpnIP = ""; mayHaveVPNSession = false; setStatus("VPN 已断开")
                        return
                    }
                    try await Task.sleep(nanoseconds: 1_000_000_000)
                }
                setStatus("VPN 正在结束连接，请稍候", kind: 1)
            } catch { setStatus(error.localizedDescription, kind: 3) }
        }
    }

    func prepareToQuit() async -> Bool {
        guard !isQuitting else { return false }
        isQuitting = true
        setStatus("正在结束登录并退出…", kind: 1)
        loginTask?.cancel()
        vpnMonitor?.cancel()
        // Browser cleanup must not delay stopping the tunnel.
        Task { await authenticationBrowser.close() }
        isBusy = true
        defer { isBusy = false }
        setStatus("正在断开 VPN 并退出…", kind: 1)
        if mayHaveVPNSession || isConnected {
            do {
                let deadline = ProcessInfo.processInfo.systemUptime + 16
                try await vpnService.stop()
                try Task.checkCancellation()
                while ProcessInfo.processInfo.systemUptime < deadline {
                    let state = try await vpnService.status()
                    try Task.checkCancellation()
                    recordServiceState(state.phase, ip: state.ip, error: state.error)
                    if ["idle", "failed", "busy"].contains(state.phase) {
                        isConnected = false; vpnIP = ""; mayHaveVPNSession = false
                        vpnService.invalidate()
                        canTerminate = true
                        return true
                    }
                    try await Task.sleep(nanoseconds: 250_000_000)
                }
            } catch { }
            isQuitting = false
            setStatus("无法确认 VPN 已断开，请重试退出", kind: 3)
            if isConnected { monitorConnection() }
            return false
        }
        vpnService.invalidate()
        canTerminate = true
        return true
    }

    func cancelQuitWaiting() {
        isQuitting = false
        isBusy = false
        setStatus("退出等待已结束，请重试或选择强制退出", kind: 3)
    }

    func forceQuit() {
        loginTask?.cancel()
        vpnMonitor?.cancel()
        authenticationBrowser.release()
        // Closing the authenticated XPC peer makes the helper stop only
        // this peer's tunnel, including its normal bounded kill fallback.
        vpnService.invalidate()
        canTerminate = true
    }

    private func keychainRead(account: String) -> String? {
        var query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        query.removeAll()
        return String(data: data, encoding: .utf8)
    }

    private func keychainWrite(_ value: String, account: String) {
        keychainDelete(account: account)
        let item: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecValueData as String: Data(value.utf8)]
        SecItemAdd(item as CFDictionary, nil)
    }

    private func keychainDelete(account: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
    }
}

struct ContentView: View {
    @StateObject private var model = VPNViewModel()
    private let acid = Color(red: 0.76, green: 1.0, blue: 0.11)

    var body: some View {
        ZStack {
            Color(red: 0.04, green: 0.055, blue: 0.06).ignoresSafeArea()
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 22) {
                    if let image = NSImage(named: "KSIcon") {
                        Image(nsImage: image).resizable().scaledToFit().frame(width: 120, height: 44)
                    }
                    VStack(alignment: .leading, spacing: 5) {
                        Text("KSVPN").font(.system(size: 30, weight: .bold, design: .rounded)).foregroundColor(.white)
                        Text("VPN").font(.system(size: 18, weight: .bold)).foregroundColor(acid)
                    }
                }
                Text("企业安全连接  /  自动获取个人配置").foregroundColor(.secondary).padding(.top, 18)
                Divider().overlay(Color.white.opacity(0.15)).padding(.vertical, 26)

                Text("使用飞书身份快速连接").font(.headline).foregroundColor(.white)
                Text("无需输入账号或密码，浏览器验证后自动连接。").foregroundColor(.secondary).padding(.top, 6)
                Button(action: model.connectWithFeishu) {
                    HStack { Text(model.isBusy ? "正在处理…" : "飞书登录并连接").fontWeight(.bold); Spacer(); Text("→") }
                        .padding(.horizontal, 18).frame(maxWidth: .infinity).frame(height: 52)
                        .background(acid).contentShape(Rectangle())
                }.buttonStyle(.plain).foregroundColor(.black).background(acid).clipShape(RoundedRectangle(cornerRadius: 10)).disabled(model.isBusy || model.isConnected || model.isQuitting)
                    .padding(.top, 16)

                HStack { Rectangle().frame(height: 1); Text("或使用 LDAP 账号").font(.caption); Rectangle().frame(height: 1) }
                    .foregroundColor(.white.opacity(0.22)).padding(.vertical, 24)

                Text("VPN 账号").font(.caption).foregroundColor(.secondary)
                TextField("例如 wangqiang", text: $model.username).textFieldStyle(.plain).padding(12).background(Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
                Text("VPN 密码").font(.caption).foregroundColor(.secondary).padding(.top, 14)
                SecureField("请输入 VPN 密码", text: $model.password).textFieldStyle(.plain).padding(12).background(Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
                Text("动态码（仅 TOTP 账号填写，其他账号留空）").font(.caption).foregroundColor(.secondary).padding(.top, 14)
                TextField("6 位动态码", text: $model.otpCode).textFieldStyle(.plain).padding(12).background(Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
                    .disableAutocorrection(true)
                Toggle("安全记住密码（保存在 macOS 钥匙串）", isOn: $model.rememberPassword).toggleStyle(.checkbox).foregroundColor(.secondary).padding(.top, 14)

                HStack(spacing: 12) {
                    Button("账号登录并连接", action: model.connectWithAccount).buttonStyle(.bordered).controlSize(.large).disabled(model.isBusy || model.isConnected || model.isQuitting)
                    Button("断开 VPN", action: model.disconnect).buttonStyle(.bordered).controlSize(.large).disabled(!model.isConnected || model.isQuitting)
                }.padding(.top, 18)

                Button("查看连接日志") {
                    let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("KSVPN")
                    NSWorkspace.shared.open(base)
                }.buttonStyle(.link).padding(.top, 12)
                Spacer()
                if let remaining = model.authSecondsRemaining {
                    Text("认证剩余 \(remaining) 秒").font(.caption).foregroundColor(acid)
                }
                Text(model.isConnected ? (model.vpnIP.isEmpty ? "VPN IP：等待分配" : "VPN IP：\(model.vpnIP)") : "VPN IP：未连接")
                    .font(.system(.callout, design: .monospaced)).foregroundColor(model.isConnected ? acid : .secondary).textSelection(.enabled).padding(.bottom, 6)
                Text(model.status).font(.callout).foregroundColor(model.statusKind == 2 ? acid : model.statusKind == 3 ? .red : .secondary).lineLimit(3).textSelection(.enabled)
            }.padding(36)
        }.frame(width: 520, height: 740)
            .background(WindowCloseBehavior(model: model).frame(width: 0, height: 0))
    }
}

@main
struct KSVPNApp: App {
    @NSApplicationDelegateAdaptor(VPNApplicationDelegate.self) private var appDelegate
    var body: some Scene {
        Window("KSVPN", id: "main") { ContentView().preferredColorScheme(.dark) }
            .windowResizability(.contentSize)
    }
}
