import Foundation

enum ProfilePolicy {
    static func sanitized(_ data: Data) throws -> Data {
        guard data.count <= 1_048_576, let text = String(data: data, encoding: .utf8), !text.contains("\0") else { throw PolicyError.invalid }
        let allowed: Set<String> = ["client", "dev", "proto", "remote", "remote-random", "remote-random-hostname", "resolv-retry", "nobind", "persist-key", "persist-tun", "remote-cert-tls", "verify-x509-name", "cipher", "data-ciphers", "data-ciphers-fallback", "auth", "auth-nocache", "tls-version-min", "tls-version-max", "tls-cipher", "tls-ciphersuites", "key-direction", "reneg-sec", "sndbuf", "rcvbuf", "verb", "mute", "mute-replay-warnings", "explicit-exit-notify", "ping", "ping-restart", "connect-retry", "connect-timeout", "server-poll-timeout", "tun-mtu", "mssfix", "fragment", "comp-lzo", "compress", "allow-compression", "pull", "route", "route-ipv6", "redirect-gateway", "redirect-private", "route-nopull", "route-delay", "topology", "dhcp-option"]
        let blocks: Set<String> = ["ca", "cert", "key", "tls-auth", "tls-crypt", "tls-crypt-v2", "crl-verify"]
        var active: String?
        var output: [String] = []
        var inlineCA = false
        for raw in text.components(separatedBy: .newlines) {
            guard raw.utf8.count < 65_536 else { throw PolicyError.invalid }
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if let block = active {
                if line == "</\(block)>" { active = nil }
                else if line.hasPrefix("<") { throw PolicyError.invalid }
                output.append(raw)
                continue
            }
            if line.isEmpty || line.hasPrefix("#") || line.hasPrefix(";") { continue }
            if line.hasPrefix("<"), line.hasSuffix(">") {
                let tag = String(line.dropFirst().dropLast())
                guard blocks.contains(tag) else { throw PolicyError.invalid }
                if tag == "ca" { inlineCA = true }
                active = tag; output.append(line); continue
            }
            let tokens = line.split(whereSeparator: { $0.isWhitespace }).map(String.init)
            guard let key = tokens.first, !line.contains("\\"), !key.hasPrefix("-"), !line.contains("\r") else { throw PolicyError.invalid }
            if key == "auth-user-pass", tokens.count == 1 { continue }
            if tokens == ["setenv", "opt", "block-outside-dns"] { continue }
            if tokens.count >= 3, tokens[0] == "setenv", tokens[1] == "FRIENDLY_NAME" { continue }
            guard allowed.contains(key) else { throw PolicyError.invalid }
            if key == "dev" { guard tokens == ["dev", "tun"] else { throw PolicyError.invalid } }
            if key == "remote-cert-tls" { guard tokens == ["remote-cert-tls", "server"] else { throw PolicyError.invalid } }
            if key == "verb" { continue }
            output.append(line)
        }
        guard active == nil, inlineCA else { throw PolicyError.invalid }
        return Data((output.joined(separator: "\n") + "\n").utf8)
    }

    enum PolicyError: Error { case invalid }
}
