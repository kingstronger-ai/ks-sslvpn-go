import Foundation

@objc(KSVPNServiceProtocol)
protocol VPNServiceProtocol {
    func ping(withReply reply: @escaping (String) -> Void)
    func start(profile: Data, username: String, secret: String, withReply reply: @escaping (Bool, String) -> Void)
    func status(withReply reply: @escaping (String, String, String) -> Void)
    func stop(withReply reply: @escaping () -> Void)
}

let vpnMachService = "tech.ksvpn.vpn.service"
