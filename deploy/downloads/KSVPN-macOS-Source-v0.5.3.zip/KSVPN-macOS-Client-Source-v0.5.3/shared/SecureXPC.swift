import Foundation
import Security
import XPC

let vpnMachService = "tech.ksvpn.vpn.service"

enum SecureXPC {
    static func requirement(_ text: String) throws -> SecRequirement {
        var result: SecRequirement?
        guard SecRequirementCreateWithString(text as CFString, [], &result) == errSecSuccess, let result else {
            throw IdentityError.invalid
        }
        return result
    }

    // Resolve the sender from the audit token attached by macOS to this exact message.
    // Check the required signed code identity on EVERY request/reply before using any fields.
    static func authenticates(_ message: xpc_object_t, requirement: SecRequirement) -> Bool {
        guard xpc_get_type(message) == XPC_TYPE_DICTIONARY else { return false }
        var sender: SecCode?
        guard SecCodeCreateWithXPCMessage(message, [], &sender) == errSecSuccess, let sender else { return false }
        return SecCodeCheckValidity(sender, [], requirement) == errSecSuccess
    }

    static func string(_ message: xpc_object_t, _ key: String) -> String {
        guard let value = xpc_dictionary_get_string(message, key) else { return "" }
        return String(cString: value)
    }

    enum IdentityError: Error { case invalid }
}
