# KSVPN macOS 客户端源码包

版本：**v0.5.3（build 18）** · 目标平台：macOS 13+ / Apple Silicon (arm64)

## 目录

| 路径 | 内容 |
|---|---|
| `Sources/KSVPN/` | 客户端 App 全部 Swift 源码（7 个文件） |
| `helper/main.swift` | 特权后台服务（LaunchDaemon）完整源码 |
| `shared/` | App 与 Helper 共用的 XPC 身份校验、配置白名单；`VPNServiceProtocol.swift` 为历史接口，不参与编译 |
| `pkgroot/` | 完整安装包目录骨架：App、Helper、LaunchDaemon、Service 绑定、OpenVPN 引擎与许可证 |
| `scripts/` | preinstall / postinstall |
| `resources/` | 安装器欢迎页 |
| `Distribution.xml` | productbuild 分发定义 |
| `app.entitlements` | App 签名 entitlements |
| `build.sh` | 一键重编译 App + Helper、双向签名、校验并打包 |

## 一键构建

需要 Xcode Command Line Tools，在 Apple Silicon Mac 上执行：

```sh
./build.sh                # 默认 0.5.3 / build 18
./build.sh 0.5.4 19       # 指定版本号与 build 号
```

产物在 `build/run.<版本>.<build>/products/`：中英双份 pkg 与 `SHA256SUMS.txt`。
脚本不会安装应用、不会加载系统服务、不会连接 VPN。

## 标识与握手

- Mach 服务名：`tech.ksvpn.vpn.service`
- Helper：`/Library/PrivilegedHelperTools/tech.ksvpn.vpn.helper`
- LaunchDaemon：`/Library/LaunchDaemons/tech.ksvpn.vpn.service.plist`
- 服务目录：`/Library/Application Support/KSVPN`
- 会话目录：`/private/var/run/tech.ksvpn.vpn`

App 与 Helper 采用**双向 cdhash 互验**：Helper 读 `Service/client-requirement.txt` 校验 App，
App 读 `Service/helper-requirement.txt` 校验 Helper。`build.sh` 在每次重编译后自动刷新这两个文件；
**手工替换任一二进制都必须同步刷新对应绑定**，否则 XPC 握手失败、客户端无法连接。

Helper 在启动 OpenVPN 前会校验 `Engine/manifest.json` 里的 `engineSHA256` 与 `dnsSHA256`。
若重新签名或替换引擎二进制，必须同时更新 manifest，否则启动会被拒绝。

## 构建要点

- 本机若对 `.swift` 启用透明加密，源码落盘可能变成密文；可把明文保存为 `.swift.txt`，
  再用绝对路径符号链接 `*.swift -> *.swift.txt` 后编译符号链接。`build.sh` 会检测并提示。
- 编译 App 时**排除** `shared/VPNServiceProtocol.swift`（与 `SecureXPC.swift` 重复声明服务名）。
- `import XPC` 可直接使用，**不要**加 `-framework XPC`。
- 编译 Helper 需要 4 个文件：`SecureXPC.swift`、`ProfilePolicy.swift`、`TunnelAddress.swift`、`helper/main.swift`。
- 签名使用 ad-hoc hardened runtime，安装包**未做 Developer ID 签名与公证**。
  装后若提示「已损坏」：`sudo xattr -rd com.apple.quarantine /Applications/KSVPN.app`。

## 版本演进

| 版本 | 变更 |
|---|---|
| v0.5.3 | 系统标识整体统一：App、Helper、LaunchDaemon、服务目录、会话目录、引擎签名标识全部改为 KSVPN 命名；Helper 源码纳入源码包，可重新编译；双向 cdhash 重新绑定 |
| v0.5.2 | 适配服务端 HALT 踢下线，修正误导文案 |
| v0.5.1 | 注入 ovpn 心跳，缩短服务端断开感知；拆分被踢与认证失败文案 |
| v0.5.0 | TOTP 双兼容修复 |
| v0.4.9 | 透明 logo、错误透出 |
| v0.4.8 | 品牌更名、点 X 退出断线 |

## 使用提示

- 换网关/端口无需重打包：编辑 `~/Library/Application Support/KSVPN/gateway.txt` 写一行地址，重启客户端。
- 被踢下线后凭据仍有效，点「账号登录并连接」即可恢复；TOTP 账号需重新填 6 位动态码。
- 云端固定分发入口与源码包节点链接保持不变，源码变更时替换同一节点内容。

## 校验值

- v0.5.3 安装包 SHA256：见同目录 `SHA256SUMS.txt`
