#!/bin/bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
VERSION=${1:-0.5.3}
BUILD=${2:-18}
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "版本号格式应为 X.Y.Z" >&2; exit 64; }
[[ $(uname -m) == arm64 ]] || { echo "仅支持 Apple Silicon (arm64) Mac" >&2; exit 1; }
WORK="$ROOT/build/run.$VERSION.$BUILD"
rm -rf "$WORK"
mkdir -p "$WORK/components" "$WORK/products" "$WORK/module-cache"
cp -R "$ROOT/pkgroot" "$WORK/pkgroot"
APP="$WORK/pkgroot/Applications/KSVPN.app"
HELPER="$WORK/pkgroot/Library/PrivilegedHelperTools/tech.ksvpn.vpn.helper"
SERVICE="$WORK/pkgroot/Library/Application Support/KSVPN/Service"

echo "[1/6] 编译 App"
APPFILES=("$ROOT"/Sources/KSVPN/*.swift "$ROOT/shared/SecureXPC.swift" "$ROOT/shared/ProfilePolicy.swift")
for f in "${APPFILES[@]}"; do
  [[ -f "$f" ]] || { echo "缺少源码: $f" >&2; exit 1; }
  head -c 4 "$f" | grep -q '%TSD' && { echo "源码被透明加密: $f，请改用 .swift.txt 明文 + 符号链接" >&2; exit 1; }
done
xcrun swiftc -parse-as-library -O -target arm64-apple-macosx13.0 \
  -module-cache-path "$WORK/module-cache" \
  -framework SwiftUI -framework AppKit -framework Security \
  "${APPFILES[@]}" -o "$APP/Contents/MacOS/KSVPN"

echo "[2/6] 编译 Helper"
xcrun swiftc -target arm64-apple-macosx13.0 \
  -module-cache-path "$WORK/module-cache" \
  -framework Security -framework CryptoKit \
  "$ROOT/shared/SecureXPC.swift" "$ROOT/shared/ProfilePolicy.swift" \
  "$ROOT/Sources/KSVPN/TunnelAddress.swift" "$ROOT/helper/main.swift" -o "$HELPER"

echo "[3/6] 版本号与分发定义"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $VERSION" \
  -c "Set :CFBundleVersion $BUILD" "$APP/Contents/Info.plist" >/dev/null
python3 - "$ROOT/Distribution.xml" "$WORK/Distribution.xml" "$VERSION" "$BUILD" <<'PYEOF'
import re,sys
s=open(sys.argv[1],encoding='utf-8').read()
s=re.sub(r'(pkg-ref id="tech\.ksvpn\.vpn\.full" )version="[0-9.]+"',r'\1version="'+sys.argv[3]+'"',s)
s=re.sub(r'CFBundleShortVersionString="[0-9.]+"','CFBundleShortVersionString="'+sys.argv[3]+'"',s)
s=re.sub(r'CFBundleVersion="[0-9]+"','CFBundleVersion="'+sys.argv[4]+'"',s)
open(sys.argv[2],'w',encoding='utf-8').write(s)
PYEOF

echo "[4/6] 双向签名与 cdhash 绑定"
codesign --force --deep --sign - "$APP"
codesign --force --options runtime --sign - "$HELPER"
CA=$(codesign -d -vvv "$APP/Contents/MacOS/KSVPN" 2>&1 | awk -F= '/^CDHash=/{print $2; exit}')
CH=$(codesign -d -vvv "$HELPER" 2>&1 | awk -F= '/^CDHash=/{print $2; exit}')
[[ "$CA" =~ ^[a-f0-9]{40}$ ]] && [[ "$CH" =~ ^[a-f0-9]{40}$ ]] || { echo "取 CDHash 失败" >&2; exit 1; }
printf 'cdhash H"%s"\n' "$CA" > "$SERVICE/client-requirement.txt"
printf 'cdhash H"%s"\n' "$CH" > "$SERVICE/helper-requirement.txt"
echo "  App    $CA"
echo "  Helper $CH"

echo "[5/6] 签名与策略自检"
codesign --verify --deep --strict "$APP"
codesign --verify --strict "$HELPER"
codesign --verify --strict "$WORK/pkgroot/Library/Application Support/KSVPN/Engine/openvpn"
"$HELPER" --self-test
"$HELPER" --self-test-ipc "$CH"
sh -n "$ROOT/scripts/preinstall" && sh -n "$ROOT/scripts/postinstall"
python3 - "$WORK/pkgroot" <<'PYEOF'
import hashlib,json,sys,os
e=os.path.join(sys.argv[1],'Library/Application Support/KSVPN/Engine')
m=json.load(open(os.path.join(e,'manifest.json')))
for k,f in [('engineSHA256','openvpn'),('dnsSHA256','dns-updown')]:
    h=hashlib.sha256(open(os.path.join(e,f),'rb').read()).hexdigest()
    if h!=m[k]: raise SystemExit('引擎哈希与 manifest 不一致: '+f)
print('  manifest 校验通过')
PYEOF

echo "[6/6] 打包"
pkgbuild --root "$WORK/pkgroot" --identifier tech.ksvpn.vpn.full --version "$VERSION" \
  --scripts "$ROOT/scripts" --install-location / "$WORK/components/KSVPN-Full-component.pkg" >/dev/null
EN="$WORK/products/KSVPN-macOS13+-arm64-Full-Installer-v$VERSION.pkg"
CN="$WORK/products/KSVPN-macOS13+-arm64-全量安装包-v$VERSION.pkg"
productbuild --distribution "$WORK/Distribution.xml" --package-path "$WORK/components" \
  --resources "$ROOT/resources" --version "$VERSION" "$EN" >/dev/null
cp "$EN" "$CN"
(cd "$WORK/products" && shasum -a 256 ./*.pkg > SHA256SUMS.txt)
printf '构建完成（未安装、未连接 VPN）：%s\n' "$WORK/products"
