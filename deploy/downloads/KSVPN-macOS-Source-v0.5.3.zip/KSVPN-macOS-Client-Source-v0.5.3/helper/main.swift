import Foundation
import Security
import CryptoKit
import Darwin
import XPC

private let serviceRoot = "/Library/Application Support/KSVPN"
private let enginePath = serviceRoot + "/Engine/openvpn"
private let dnsPath = serviceRoot + "/Engine/dns-updown"
private let requirementPath = serviceRoot + "/Service/client-requirement.txt"
private let manifestPath = serviceRoot + "/Engine/manifest.json"

private func rootFile(_ path: String) throws -> Data {
    var info = stat()
    guard lstat(path, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG,
          info.st_uid == 0, (info.st_mode & 0o022) == 0 else { throw ServiceError.invalidInstall }
    return try Data(contentsOf: URL(fileURLWithPath: path))
}

private enum ServiceError: Error { case invalidInstall, busy, invalidCredentials }

private final class EngineState {
    let queue = DispatchQueue(label: "tech.ksvpn.vpn.engine")
    private var process: Process?
    private var owner: UUID?
    private var directory: URL?
    private var phase = "idle"
    private var address = ""
    private var failure = ""
    private var started: TimeInterval = 0
    private var stopping: TimeInterval?
    private var timer: DispatchSourceTimer?

    init() {
        let timer = DispatchSource.makeTimerSource(queue: queue)
        timer.schedule(deadline: .now() + 1, repeating: 1)
        timer.setEventHandler { [weak self] in self?.refresh() }
        timer.resume()
        self.timer = timer
    }

    func start(owner: UUID, profile: Data, username: String, secret: String) throws {
        guard process == nil else { throw ServiceError.busy }
        guard username.range(of: #"^[A-Za-z0-9_.-]{1,64}$"#, options: .regularExpression) != nil,
              !secret.isEmpty, secret.utf8.count <= 8192,
              !secret.contains("\n"), !secret.contains("\r"), !secret.contains("\0") else { throw ServiceError.invalidCredentials }
        let cleaned = try ProfilePolicy.sanitized(profile)
        let manifest = try JSONSerialization.jsonObject(with: rootFile(manifestPath)) as? [String: String]
        let engine = try rootFile(enginePath), dns = try rootFile(dnsPath)
        let hash: (Data) -> String = { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() }
        guard manifest?["engineSHA256"] == hash(engine), manifest?["dnsSHA256"] == hash(dns), manifest?["api"] == "1" else { throw ServiceError.invalidInstall }
        let fm = FileManager.default
        let base = URL(fileURLWithPath: "/private/var/run/tech.ksvpn.vpn", isDirectory: true)
        try fm.createDirectory(at: base, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        let dir = base.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        var launched = false
        defer { if !launched { try? fm.removeItem(at: dir) } }
        func write(_ name: String, _ data: Data) throws -> URL {
            let url = dir.appendingPathComponent(name)
            guard fm.createFile(atPath: url.path, contents: data, attributes: [.posixPermissions: 0o600]) else { throw ServiceError.invalidInstall }
            return url
        }
        let config = try write("profile.ovpn", cleaned)
        let credentials = try write("auth.txt", Data("\(username)\n\(secret)\n".utf8))
        let log = try write("openvpn.log", Data())
        let startup = try write("startup.log", Data())
        let output = try FileHandle(forWritingTo: startup)
        let child = Process()
        child.executableURL = URL(fileURLWithPath: enginePath)
        let dnsCommand = "\"" + dnsPath.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
        child.arguments = ["--config", config.path, "--auth-user-pass", credentials.path, "--auth-nocache", "--verb", "3", "--log-append", log.path, "--dns-updown", dnsCommand, "--script-security", "2"]
        child.currentDirectoryURL = dir
        child.environment = ["PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": "/var/root", "LANG": "C"]
        child.standardInput = FileHandle.nullDevice
        child.standardOutput = output; child.standardError = output
        child.terminationHandler = { [weak self, weak child] _ in
            guard let self, let child else { return }
            self.queue.async { self.finished(child) }
        }
        try child.run()
        try? output.close()
        self.process = child; self.owner = owner; self.directory = dir
        self.phase = "connecting"; self.address = ""; self.failure = ""
        self.started = ProcessInfo.processInfo.systemUptime; self.stopping = nil
        launched = true
    }

    func status(owner: UUID) -> (String, String, String) {
        if let active = self.owner, active != owner { return ("busy", "", "另一客户端正在使用 VPN") }
        refresh()
        return (phase, address, failure)
    }

    func stop(owner: UUID) {
        guard self.owner == owner, let process else { return }
        phase = "stopping"; stopping = ProcessInfo.processInfo.systemUptime
        if process.isRunning { process.terminate() }
    }

    private func logs() -> String {
        guard let directory else { return "" }
        return ["openvpn.log", "startup.log"].map {
            guard let file = try? FileHandle(forReadingFrom: directory.appendingPathComponent($0)) else { return "" }
            defer { try? file.close() }
            let end = (try? file.seekToEnd()) ?? 0
            try? file.seek(toOffset: end > 131072 ? end - 131072 : 0)
            let data = (try? file.readToEnd()) ?? Data()
            return String(data: data, encoding: .utf8) ?? ""
        }.joined(separator: "\n")
    }

    private func refresh() {
        guard let process else { return }
        let log = logs()
        if phase == "connecting", log.contains("Initialization Sequence Completed"), process.isRunning {
            phase = "connected"; address = TunnelAddress.ipv4(in: log)
        }
        if phase == "connecting", ProcessInfo.processInfo.systemUptime - started > 90 {
            failure = "VPN 连接超时，请检查服务端与网络"; phase = "stopping"; stopping = ProcessInfo.processInfo.systemUptime
            if process.isRunning { process.terminate() }
        }
        if let stopping, process.isRunning, ProcessInfo.processInfo.systemUptime - stopping > 10 { kill(process.processIdentifier, SIGKILL) }
    }

    private func finished(_ child: Process) {
        guard process === child else { return }
        let log = logs().lowercased()
        if phase == "stopping", failure.isEmpty { phase = "idle" }
        else {
            phase = "failed"
            if log.contains("auth_failed") { failure = "VPN 账号或密码错误，服务器拒绝登录" }
            else if log.contains("verify error") || log.contains("tls error") { failure = "VPN 证书验证或 TLS 握手失败" }
            else if log.contains("options error") { failure = "个人 VPN 配置与引擎不兼容" }
            else if failure.isEmpty { failure = "VPN 进程已结束，请检查网络后重新连接" }
        }
        if let directory { try? FileManager.default.removeItem(at: directory) }
        self.process = nil; self.owner = nil; self.directory = nil; self.address = ""; self.stopping = nil
    }
}

private final class Peer {
    let identity = UUID()
    let connection: xpc_connection_t
    let state: EngineState
    let requirement: SecRequirement

    init(connection: xpc_connection_t, state: EngineState, requirement: SecRequirement) {
        self.connection = connection; self.state = state; self.requirement = requirement
    }

    func receive(_ message: xpc_object_t) {
        guard xpc_get_type(message) == XPC_TYPE_DICTIONARY else {
            if xpc_get_type(message) == XPC_TYPE_ERROR { state.queue.async { self.state.stop(owner: self.identity) } }
            return
        }
        guard xpc_connection_get_euid(connection) >= 500,
              SecureXPC.authenticates(message, requirement: requirement) else {
            if let reply = xpc_dictionary_create_reply(message) {
                xpc_dictionary_set_string(reply, "error", "客户端签名身份不匹配")
                xpc_dictionary_set_bool(reply, "ok", false)
                xpc_connection_send_message(connection, reply)
            }
            xpc_connection_cancel(connection)
            return
        }
        guard let reply = xpc_dictionary_create_reply(message) else { return }
        let operation = SecureXPC.string(message, "op")
        state.queue.async {
            switch operation {
            case "ping":
                xpc_dictionary_set_string(reply, "version", "1")
                xpc_dictionary_set_bool(reply, "ok", true)
            case "status":
                let value = self.state.status(owner: self.identity)
                xpc_dictionary_set_string(reply, "phase", value.0)
                xpc_dictionary_set_string(reply, "ip", value.1)
                xpc_dictionary_set_string(reply, "error", value.2)
                xpc_dictionary_set_bool(reply, "ok", true)
            case "stop":
                self.state.stop(owner: self.identity)
                xpc_dictionary_set_bool(reply, "ok", true)
            case "start":
                var size = 0
                guard let bytes = xpc_dictionary_get_data(message, "profile", &size), size <= 1_048_576 else {
                    xpc_dictionary_set_string(reply, "error", "个人配置大小无效")
                    xpc_connection_send_message(self.connection, reply); return
                }
                do {
                    try self.state.start(owner: self.identity, profile: Data(bytes: bytes, count: size),
                                         username: SecureXPC.string(message, "username"), secret: SecureXPC.string(message, "secret"))
                    xpc_dictionary_set_bool(reply, "ok", true)
                } catch ServiceError.busy { xpc_dictionary_set_string(reply, "error", "已有 VPN 连接，请先断开") }
                catch is ProfilePolicy.PolicyError { xpc_dictionary_set_string(reply, "error", "个人配置包含不支持的指令或外置文件，请联系管理员") }
                catch ServiceError.invalidCredentials { xpc_dictionary_set_string(reply, "error", "VPN 凭据格式无效") }
                catch { xpc_dictionary_set_string(reply, "error", "VPN 后台服务或引擎安装不完整，请使用全量安装包修复") }
            default:
                xpc_dictionary_set_string(reply, "error", "不支持的 VPN 服务请求")
            }
            xpc_connection_send_message(self.connection, reply)
        }
    }
}

private func accept(_ listener: xpc_connection_t, state: EngineState, requirement: SecRequirement) {
    xpc_connection_set_event_handler(listener) { event in
        guard xpc_get_type(event) == XPC_TYPE_CONNECTION else { return }
        let peer = Peer(connection: event, state: state, requirement: requirement)
        xpc_connection_set_event_handler(event) { peer.receive($0) }
        xpc_connection_resume(event)
    }
    xpc_connection_resume(listener)
}

if CommandLine.arguments.contains("--self-test") {
    let valid = Data("client\ndev tun\nremote example.invalid 1194\nauth-user-pass\n<ca>\nTEST-ONLY-NOT-A-CERTIFICATE\n</ca>\n".utf8)
    precondition((try? ProfilePolicy.sanitized(valid)) != nil)
    for directive in ["up /tmp/evil", "plugin /tmp/evil", "config /tmp/evil", "script-security 3", "setenv PATH /tmp", "management localhost 1234", "ca /tmp/evil", "--up /tmp/evil", "<connection>\nremote localhost\n</connection>"] {
        precondition((try? ProfilePolicy.sanitized(valid + Data((directive + "\n").utf8))) == nil)
    }
    print("Profile policy allowlist and injection rejection PASS")
    exit(0)
}

if let index = CommandLine.arguments.firstIndex(of: "--self-test-ipc"), CommandLine.arguments.count > index + 1 {
    let hash = CommandLine.arguments[index + 1]
    guard hash.range(of: "^[a-f0-9]{40}$", options: .regularExpression) != nil,
          let requirement = try? SecureXPC.requirement("cdhash H\"\(hash)\"") else { exit(64) }
    let queue = DispatchQueue(label: "tech.ksvpn.vpn.ipctest")
    let listener = xpc_connection_create(nil, queue)
    accept(listener, state: EngineState(), requirement: requirement)
    let endpoint = xpc_endpoint_create(listener)
    let client = xpc_connection_create_from_endpoint(endpoint)
    xpc_connection_set_event_handler(client) { _ in }
    xpc_connection_resume(client)
    let message = xpc_dictionary_create(nil, nil, 0)
    xpc_dictionary_set_string(message, "op", "ping")
    let semaphore = DispatchSemaphore(value: 0)
    var passed = false
    xpc_connection_send_message_with_reply(client, message, queue) { reply in
        passed = SecureXPC.authenticates(reply, requirement: requirement) && SecureXPC.string(reply, "version") == "1"
        semaphore.signal()
    }
    let waited = semaphore.wait(timeout: .now() + 8)
    xpc_connection_cancel(client); xpc_connection_cancel(listener)
    guard waited == .success, passed else { fputs("Audited XPC self-test failed.\n", stderr); exit(1) }
    print("Per-message audit-token code signature checks and XPC ping PASS")
    exit(0)
}

guard geteuid() == 0 else { fputs("Helper must be launched by the installed system service.\n", stderr); exit(77) }
do {
    let text = String(data: try rootFile(requirementPath), encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    guard text.hasPrefix("cdhash H\""), text.hasSuffix("\"") else { throw ServiceError.invalidInstall }
    let requirement = try SecureXPC.requirement(text)
    let listener = xpc_connection_create_mach_service(vpnMachService, DispatchQueue.global(), UInt64(XPC_CONNECTION_MACH_SERVICE_LISTENER))
    accept(listener, state: EngineState(), requirement: requirement)
    dispatchMain()
} catch { fputs("Invalid helper installation.\n", stderr); exit(78) }
